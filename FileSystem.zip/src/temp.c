#include<stdio.h>

int main(){

    printf("Temp\n");
    return 0;
}